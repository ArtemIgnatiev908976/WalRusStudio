$('#typeanim').typeIt({
        speed: 125,
        breakLines: false,
        autoStart: false,
        loop: true,
        html: true,
    })
    .tiType('Продвигаем.')
    .tiPause(3000)
    .tiDelete(11)
    .tiType('Развиваем.')
    .tiPause(3000)
    .tiDelete(10)
    .tiType('Создаем.')
    .tiPause(3000)


$('#typeanim2').typeIt({
        speed: 125,
        breakLines: false,
        autoStart: false,
        loop: true,
        html: true,
})
    .tiType('Продвигаем.')
    .tiPause(3000)
    .tiDelete(11)
    .tiType('Развиваем.')
    .tiPause(3000)
    .tiDelete(10)
    .tiType('Создаем.')
    .tiPause(3000)